﻿using Microsoft.AspNetCore.JsonPatch;
using EmployeeAPIPOC.IServices;
using System.Collections.Generic;
using System.Linq;
using EmployeeAPIPOC.Models;

namespace EmployeeAPIPOC.Repository
{
    public class EmployeeRepository : IEmployeeService
    {
        public List<Employee> Get()
        {
            List<Employee> empList = new List<Employee>()
            {
                new Employee {EmpID=1, EmpName="Rakshith",EmpDesignation="I1",Salary=1000, Status= true },
                new Employee {EmpID=2, EmpName="Rahul", EmpDesignation="I2",Salary=2000, Status = true },
                new Employee {EmpID=3, EmpName="arun", EmpDesignation="I3",Salary=3000, Status = false},
                new Employee {EmpID=3, EmpName="ramesh", EmpDesignation="I4",Salary=4000, Status = false}
            };
            return empList;
        }

        public Employee GetBy(int id)
        {
            List<Employee> empList = Get();
            Employee Employee = empList.Where(x => x.EmpID == id).FirstOrDefault();
            if (Employee != null)
            {
                return Employee;
            }
            else
            {
                return null;
            }
        }

        public List<Employee> Create(Employee Employee)
        {
            List<Employee> empList = Get();
            empList.Add(Employee);
            return empList;
        }

        public List<Employee> Delete(int id)
        {
            List<Employee> empList = Get();
            var itemToRemove = empList.SingleOrDefault(r => r.EmpID == id);
            if (itemToRemove != null)
            {
                empList.Remove(itemToRemove);
                return empList;
            }
            else
            {
                return null;
            }
        }

        public List<Employee> Update(Employee Employee)
        {
            List<Employee> empList = Get();
            var updateEmployee = empList.Where(x => x.EmpID == Employee.EmpID).FirstOrDefault();
            if (updateEmployee != null)
            {
                updateEmployee.EmpName = Employee.EmpName;
                updateEmployee.EmpDesignation = Employee.EmpDesignation;
                updateEmployee.Salary = Employee.Salary;
                return empList;
            }
            else
            {
                return null;
            }
        }

        public Employee UpdateByPatch(int id, JsonPatchDocument<Employee> Employee)
        {
            List<Employee> empList = Get();
            var result = empList.FirstOrDefault(n => n.EmpID == id);
            if (result == null)
            {
                return null;
            }
            Employee.ApplyTo(result);//result gets the values from the patch request
            return result;
        }

        public List<Employee> GetActiveOrDeactiveemployees(bool status)
        {
            List<Employee> empList = Get();
            empList = empList.FindAll(x => x.Status == status).ToList();
            if (empList != null)
            {
                return empList;
            }
            else
            {
                return null;
            }
        }

        public bool IsValidUserInformation(LoginModel model)
        {
            throw new System.NotImplementedException();
        }
    }
}

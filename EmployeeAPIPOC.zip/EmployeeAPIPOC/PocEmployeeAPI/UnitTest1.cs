using Microsoft.AspNetCore.Mvc;
using EmployeeAPIPOC;
using EmployeeAPIPOC.Controllers;
using System.Collections.Generic;
using Xunit;

namespace PocEmployeeAPI
{
    public class EmployeeXunit
    {
        private readonly IJwtAuth _jwtAuth = null;
        Employee employee = new Employee();
        List<Employee> EmployeeList = new List<Employee>();

        [Fact]
        public void Get()
        {
            EmployeeController EmployeeController = new EmployeeController(_jwtAuth);
            var result = EmployeeController.Get();
            var okResult = result as ObjectResult;
            if (okResult.StatusCode == 404)
            {
                Assert.Equal(404, okResult.StatusCode);
            }
            else if (okResult.StatusCode == 400)
            {
                Assert.Equal(400, okResult.StatusCode);
            }
            else if (okResult.StatusCode == 200)
            {
                Assert.Equal(200, okResult.StatusCode);
            }
        }

        [Fact]
        public void GetbyId()
        {
            int id = 1;
            EmployeeController EmployeeController = new(_jwtAuth);
            var result = EmployeeController.GetBy(id);
            var okResult = result as ObjectResult;
            if (okResult.StatusCode == 404)
            {
                Assert.Equal(404, okResult.StatusCode);
            }
            else if (okResult.StatusCode == 400)
            {
                Assert.Equal(400, okResult.StatusCode);
            }
            else if (okResult.StatusCode == 200)
            {
                Assert.Equal(200, okResult.StatusCode);
            }
        }

        [Fact]
        public void Create()
        {
            EmployeeController EmployeeController = new EmployeeController(_jwtAuth);
            Employee Employee = new Employee { EmpID = 5, EmpName = "aeee", Salary = 6000,EmpDesignation= "B2" };
            var result = EmployeeController.Create(Employee);
            var okResult = result as ObjectResult;
            if (okResult.StatusCode == 404)
            {
                Assert.Equal(404, okResult.StatusCode);
            }
            else if (okResult.StatusCode == 400)
            {
                Assert.Equal(expected: 400, okResult.StatusCode);
            }
            else if (okResult.StatusCode == 200)
            {
                Assert.Equal(200, okResult.StatusCode);
            }
        }

        [Fact]
        public void Delete()
        {
            int id = 66;
            EmployeeController EmployeeController = new EmployeeController(_jwtAuth);
            var result = EmployeeController.Delete(id);
            var okResult = result as ObjectResult;
            if (okResult.StatusCode == 404)
            {
                Assert.Equal(404, okResult.StatusCode);
            }
            else if (okResult.StatusCode == 400)
            {
                Assert.Equal(400, okResult.StatusCode);
            }
            else if (okResult.StatusCode == 200)
            {
                Assert.Equal(200, okResult.StatusCode);
            }
        }
    }
}

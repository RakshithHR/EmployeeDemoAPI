﻿//using Microsoft.EntityFrameworkCore;

//namespace EmployeesAPI.Repository
//{
//    public class EmployeeDbContext : DbContext
//    {
//        public EmployeeDbContext(DbContextOptions<EmployeeDbContext> options) : base(options)
//        {

//        }
//        public DbSet<Employee> GetAll { get; set; }
//        //protected override void OnModelCreating(ModelBuilder modelBuilder)
//        //{
//        //    modelBuilder.Entity<Employee>().ToTable("Employee");
//        //}

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<Employee>(entity =>
//            {
//                entity.Property(e => e.EmployeeName)
//                    .IsRequired()
//                    .HasMaxLength(50)
//                    .IsUnicode(false);

//                entity.Property(e => e.EmployeeFeatures)
//                    .IsRequired()
//                    .HasMaxLength(250)
//                    .IsUnicode(false);

//                entity.Property(e => e.EmployeePrice)
//                    .IsRequired()
//                    .HasColumnType("money");
//            });
//        }
//    }
//}

﻿using EmployeeAPIPOC.IServices;
using System;
using System.Collections.Generic;
using EmployeeAPIPOC.Repository;
using Microsoft.AspNetCore.JsonPatch;
using EmployeeAPIPOC.Models;

namespace EmployeeAPIPOC.Services
{
    public class EmployeeService : IEmployeeService
    {
        public List<Employee> Create(Employee employee)
        {
            List<Employee> employeesList = new EmployeeRepository().Create(employee);
            return employeesList;
        }

        public List<Employee> Delete(int id)
        {
            List<Employee> employeesList = new EmployeeRepository().Delete(id);
            return employeesList;
        }

        public List<Employee> Get()
        {
            List<Employee> employeesList = new EmployeeRepository().Get();
            return employeesList;
        }

        public Employee GetBy(int id)
        {
            Employee employee = new EmployeeRepository().GetBy(id);
            return employee;
        }

        public List<Employee> Update(Employee employee)
        {
            List<Employee> employeesList = new EmployeeRepository().Update(employee);
            return employeesList;
        }

        public Employee UpdateByPatch(int id, JsonPatchDocument<Employee> employee)
        {
            Employee updatedemployee = new EmployeeRepository().UpdateByPatch(id, employee);
            return updatedemployee;
        }

        public List<Employee> GetActiveOrDeactiveemployees(bool status)
        {
            List<Employee> employeesList = new EmployeeRepository().GetActiveOrDeactiveemployees(status);
            return employeesList;
        }
        public bool IsValidUserInformation(LoginModel model)
        {
            if (model.UserName.Equals("Rahul") && model.Password.Equals("Wipro")) return true;
            else return false;
        }
        public List<LoginModel> GetUserDetails()
        {
            List<LoginModel> userListList = new List<LoginModel>()
            {
                new LoginModel {UserName="Rakshith", Password="Wipro" },
                new LoginModel {UserName="abc", Password="123" },
            };
            return userListList;
        }

       
    }
}
